"""
Part 2: how DraftKings and FanDuel price passing-prop markets during games.

    Model A  event study (distributed-lag fixed effects)
    Model B  dynamic panel (lagged overround) and price stickiness
    Model C  same-moment comparison of the two books
    Model D  market closures (linear probability model)

Usage (from the repository folder):
    python part2_models.py
or with explicit paths:
    python part2_models.py PairedOdds_with_Game_ID.xlsx "nfl_playbyplay_full_teams_updated(RAW).csv"

Requires: pandas, numpy, statsmodels, openpyxl. matplotlib is optional (figures).

Outputs:
    inplay_panel.csv        one row per book x product x in-play snapshot, with event lags
    stickiness.csv          how often each book changes its quote between snapshots
    model_a_results.csv     Model A coefficients and tests
    model_b_results.csv     Model B coefficients, persistence and dynamic multipliers
    model_c_results.csv     Model C coefficients
    model_d_results.csv     Model D coefficients and tests
    model_[a-d]_figure.png  figures (only if matplotlib is installed)
"""
import re
import sys

import numpy as np
import pandas as pd
import statsmodels.api as sm

ODDS_PATH = sys.argv[1] if len(sys.argv) > 2 else "PairedOdds_with_Game_ID.xlsx"
PBP_PATH = sys.argv[2] if len(sys.argv) > 2 else "nfl_playbyplay_full_teams_updated(RAW).csv"

BOOKS = ["DraftKings", "FanDuel"]
MARKETS = {"player_pass_yds": "yds", "player_pass_completions": "completions"}
LAGS = [-1, 0, 1, 2, 3]          # -1 is the lead (placebo); 0..3 are snapshots after the event
BLOCK_MIN = 15                    # length of the game-time blocks for the book x time effects
LAST_BLOCK = 12                   # blocks from 180 minutes on are pooled into one


# ---------------------------------------------------------------------------
# 1. Play-by-play: clean the wall-clock times
# ---------------------------------------------------------------------------
pbp = pd.read_csv(PBP_PATH, low_memory=False)
pbp["wc_raw"] = (pd.to_datetime(pbp["Wall Clock"], utc=True, errors="coerce")
                 .dt.tz_localize(None))

# A few single plays carry a wrong time (one is stamped 22 hours late) and 91
# have none. A time is repaired only if it is both far from the plays around it
# (more than 3 minutes from the median of the 7 surrounding plays) and out of
# order with its neighbours by more than a minute. Genuine pauses such as
# reviews or halftime are in order, so they are left alone. Repaired and
# missing times are replaced by that median.
G = pbp["Game ID"]
secs = (pbp["wc_raw"] - pd.Timestamp("2023-01-01")).dt.total_seconds()
med = secs.groupby(G).transform(lambda s: s.rolling(7, center=True, min_periods=3).median())
prev = secs.groupby(G).transform(lambda s: s.ffill().shift(1))
nxt = secs.groupby(G).transform(lambda s: s.bfill().shift(-1))
out_of_order = ((secs - prev) < -60) | ((nxt - secs) < -60)
bad = secs.isna() | (((secs - med).abs() > 180) & out_of_order)
pbp["wc"] = pd.Timestamp("2023-01-01") + pd.to_timedelta(secs.where(~bad, med), unit="s")
print(f"Play-by-play rows: {len(pbp)}; wall-clock times missing: {int(secs.isna().sum())}, "
      f"repaired: {int((bad & secs.notna()).sum())}")

game_times = (pbp.groupby("Game ID")["wc"].agg(["min", "max"])
              .rename(columns={"min": "first_play", "max": "last_play"}))


# ---------------------------------------------------------------------------
# 2. Odds: kickoff, in-play snapshots, and each book's main line per snapshot
# ---------------------------------------------------------------------------
odds = pd.read_excel(ODDS_PATH).dropna(subset=["Overround"])

# Data fixes found while checking the odds file:
#  - "Zach Wislon" is a typo for Zach Wilson.
#  - A few rows sit under the wrong game (for example Bryce Young and Jordan Love
#    listed under Lions at Vikings) or belong to a player who never played.
#    A player-game is kept only if the player's name appears in that game's
#    play-by-play.
odds["Player"] = odds["Player"].replace({"Zach Wislon": "Zach Wilson"})

def short_name(full):
    """'Patrick Mahomes' -> 'P.Mahomes', the format used in play descriptions."""
    full = re.sub(r"\(.*?\)", "", full).replace(" II", "").strip()
    parts = full.split()
    return parts[0][0].upper() + "." + parts[-1].capitalize() if len(parts) > 1 else full

def normalise(name):
    """'P.MAHOMES' or 'P.Mahomes' -> 'P.Mahomes'."""
    first, last = name.split(".", 1)
    return first + "." + last.capitalize()

named = (pbp["Description"].fillna("").str.findall(r"\b([A-Z][\w']*\.[\w'\-]+)")
         .explode().dropna())
named = set(zip(pbp.loc[named.index, "Game ID"], named.map(normalise)))
odds["qb"] = odds["Player"].map(short_name)
in_game = pd.Series([(g, p) in named for g, p in zip(odds["Game_ID"], odds["qb"])],
                    index=odds.index)
dropped = odds.loc[~in_game, ["Game_ID", "Player"]].drop_duplicates()
print(f"Odds rows dropped (player not in that game's play-by-play): {int((~in_game).sum())} "
      f"rows, {len(dropped)} player-games")
odds = odds[in_game].copy()

# Market Update is Eastern time; Timestamp (the snapshot) is UTC.
odds["upd"] = (odds["Market Update"]
               .dt.tz_localize("America/New_York", ambiguous="NaT", nonexistent="NaT")
               .dt.tz_convert("UTC").dt.tz_localize(None))

# Kickoff is the first play of the game, which is the opening kickoff in all
# 285 games and falls at the scheduled start time. The first odds snapshot is
# not used: on busy days collection started at 1pm Eastern for every game, so
# late games have hours of pregame snapshots, and in a few games collection
# started after the game had begun. The first snapshot is only a fallback if
# a game had no play times.
odds["first_snapshot"] = odds.groupby("Game_ID")["Timestamp"].transform("min")
odds = odds.join(game_times, on="Game_ID")
odds["kickoff"] = odds["first_play"].fillna(odds["first_snapshot"])

# The snapshot grid of each game: every distinct snapshot time after kickoff and
# up to the last play. n counts snapshots from the first in-play one (n = 0).
grid = (odds.loc[(odds["Timestamp"] > odds["kickoff"]) & (odds["Timestamp"] <= odds["last_play"]),
                 ["Game_ID", "Timestamp", "kickoff"]]
        .drop_duplicates(["Game_ID", "Timestamp"])
        .sort_values(["Game_ID", "Timestamp"]))
grid["n"] = grid.groupby("Game_ID").cumcount()
grid["minute"] = (grid["Timestamp"] - grid["kickoff"]).dt.total_seconds() / 60
grid["block"] = np.minimum((grid["minute"] // BLOCK_MIN).astype(int), LAST_BLOCK)
print(f"Games with in-play snapshots: {grid['Game_ID'].nunique()}, "
      f"snapshots: {len(grid)}")

# Quotes from the two books and two markets, in-play snapshots only.
q = odds[odds["Bookmaker"].isin(BOOKS) & odds["Market"].isin(MARKETS)].copy()
q["mk"] = q["Market"].map(MARKETS)
q = q.merge(grid[["Game_ID", "Timestamp", "n", "minute", "block"]],
            on=["Game_ID", "Timestamp"], how="inner")

# Main line: of the lines a book shows at a snapshot, the one whose de-vigged
# over probability is closest to 0.5. Ties are broken by the lower line.
q["p_over"] = q["BreakEvenOver"] / (q["BreakEvenOver"] + q["BreakEvenUnder"])
q["dist"] = (q["p_over"] - 0.5).abs()
key = ["Game_ID", "Player", "mk", "Bookmaker", "n"]
panel = (q.sort_values(key + ["dist", "Point"])
         .drop_duplicates(key)
         .copy())
panel["stale"] = (panel["Timestamp"] - panel["upd"]).dt.total_seconds() / 60
print(f"Book x product x snapshot rows (open quotes): {len(panel)}")


# ---------------------------------------------------------------------------
# 3. Events from the play-by-play
# ---------------------------------------------------------------------------
PASSER = re.compile(r"([A-Z][\w']*\.[\w'\-]+) pass")

def parse_event(desc):
    """Passer, completion flag, yards and touchdown flag for one pass play."""
    if not isinstance(desc, str):
        return None
    if "overturned." in desc:                  # keep only the final ruling
        desc = desc.split("overturned.", 1)[-1]
    if "No Play" in desc:                       # nullified by penalty
        return None
    m = PASSER.search(desc)
    if not m:
        return None
    complete = (" complete" in desc) and ("incomplete" not in desc)
    if not complete:
        return None
    g = re.search(r"Gain of (-?\d+) yards", desc)
    yards = int(g.group(1)) if g else 0
    td = int("TOUCHDOWN" in desc and "FUMBLES" not in desc)
    return m.group(1), yards, td

rows = []
passes = pbp[pbp["Play Type"] == "pass"]
for gid, wc, desc in zip(passes["Game ID"], passes["wc"], passes["Description"]):
    r = parse_event(desc)
    if r:
        rows.append({"Game_ID": gid, "wc": wc, "passer": r[0], "yards": r[1], "td": r[2]})
comp = pd.DataFrame(rows)
comp["ev_td"] = comp["td"]
comp["ev_c20"] = (comp["yards"] >= 20).astype(int)
comp["ev_c40"] = (comp["yards"] >= 40).astype(int)
EVENTS = ["ev_td", "ev_c20", "ev_c40"]
print("Completions parsed:", len(comp),
      "| touchdowns:", int(comp["ev_td"].sum()),
      "| 20+ yards:", int(comp["ev_c20"].sum()),
      "| 40+ yards:", int(comp["ev_c40"].sum()))

comp["qb"] = comp["passer"].map(normalise)

# Each event goes to the first snapshot at or after it: it happened in the
# window between snapshot n-1 and snapshot n, so it is "k = 0" at snapshot n.
def assign_window(ev):
    out = []
    for gid, e in ev.groupby("Game_ID"):
        g = grid[grid["Game_ID"] == gid]
        if g.empty:
            continue
        times = g["Timestamp"].values
        idx = np.searchsorted(times, e["wc"].values, side="left")
        after_kickoff = e["wc"].values > g["kickoff"].iloc[0].to_datetime64()
        keep = (idx < len(times)) & after_kickoff
        out.append(e[keep].assign(n=idx[keep]))
    return pd.concat(out, ignore_index=True)

comp_w = assign_window(comp)
print(f"Completions placed in an in-play window: {len(comp_w)} of {len(comp)}")

# Event counts per game, quarterback and snapshot, then leads and lags.
ev = comp_w.groupby(["Game_ID", "qb", "n"])[EVENTS].sum().clip(upper=1).reset_index()
lagged = []
for k in LAGS:
    shifted = ev.copy()
    shifted["n"] = shifted["n"] + k            # an event at n0 is lag k at snapshot n0 + k
    shifted = shifted.rename(columns={e: f"{e}_k{k}".replace("-", "m") for e in EVENTS})
    lagged.append(shifted.set_index(["Game_ID", "qb", "n"]))
ev_lags = pd.concat(lagged, axis=1).fillna(0).astype(int).reset_index()

panel = panel.merge(ev_lags, on=["Game_ID", "qb", "n"], how="left")
lag_cols = [c for c in panel.columns if c.startswith("ev_") and "_k" in c]
panel[lag_cols] = panel[lag_cols].fillna(0).astype(int)

# Match check: every quarterback in the panel should appear as a passer in his game.
passers = comp[["Game_ID", "qb"]].drop_duplicates()
m = panel[["Game_ID", "qb"]].drop_duplicates().merge(passers, how="left", indicator=True)
unmatched = m[m["_merge"] == "left_only"]
print(f"Quarterback-games in panel: {len(m)}; without a completion in the play-by-play: "
      f"{len(unmatched)}")

panel["book_dk"] = (panel["Bookmaker"] == "DraftKings").astype(int)
panel["entity"] = (panel["Game_ID"] + "|" + panel["Player"] + "|" + panel["mk"]
                   + "|" + panel["Bookmaker"])
out_cols = (["Game_ID", "Player", "qb", "mk", "Bookmaker", "book_dk", "entity", "Timestamp",
             "n", "minute", "block", "Point", "BreakEvenOver", "BreakEvenUnder", "Overround",
             "p_over", "dist", "upd", "stale"] + lag_cols)
panel = panel[out_cols].sort_values(["entity", "n"]).reset_index(drop=True)
panel.to_csv("inplay_panel.csv", index=False)


# ---------------------------------------------------------------------------
# 4. Model A
#    OR = product x book FE + book x time-block FE
#         + sum_k beta_k(DK) E(t-k) x DK + sum_k beta_k(FD) E(t-k) x FD
#         + theta * dist + error,  clustered by game
# ---------------------------------------------------------------------------
def model_a(df, event, with_dist=True):
    df = df.copy()
    # Products with a single observation carry no within variation.
    df = df[df.groupby("entity")["Overround"].transform("size") > 1]

    X = pd.DataFrame(index=df.index)
    for b, flag in [("DK", df["book_dk"] == 1), ("FD", df["book_dk"] == 0)]:
        for k in LAGS:
            col = f"{event}_k{k}".replace("-", "m")
            X[f"{b}_k{k}".replace("-", "m")] = df[col] * flag
        # Book x time-block dummies; block 0 is the reference for each book,
        # because each book's level is already absorbed by its product FE.
        for s in range(1, LAST_BLOCK + 1):
            X[f"{b}_block{s}"] = ((df["block"] == s) & flag).astype(float)
    if with_dist:
        X["dist"] = df["dist"]
    X = X.loc[:, X.std() > 0]                  # drop blocks that never occur

    # Within transformation: subtract each product x book mean.
    y = df["Overround"] * 100                   # percentage points
    yd = y - y.groupby(df["entity"]).transform("mean")
    Xd = X - X.groupby(df["entity"]).transform("mean")
    res = sm.OLS(yd, Xd).fit(cov_type="cluster", cov_kwds={"groups": df["Game_ID"]})
    return res, df

def wald(res, R_rows):
    names = list(res.params.index)
    R = np.zeros((len(R_rows), len(names)))
    for i, row in enumerate(R_rows):
        for name, w in row.items():
            R[i, names.index(name)] = w
    w = res.wald_test(R, scalar=True, use_f=True)
    return float(w.statistic), float(w.pvalue)

# "fresh" keeps only quotes updated in the 5 minutes before the snapshot, so a
# book is not credited with a price it set before the event. (A near-even
# restriction is not needed in-play: books keep re-centring the main line, and
# 99.99 percent of in-play main lines have a de-vigged probability within 0.15
# of one half.)
SAMPLES = {
    "main": lambda d: d,
    "fresh": lambda d: d[d["stale"] <= 5],
}

results = []
for mk in ["yds", "completions"]:
    for event in EVENTS:
        for sample, rule in SAMPLES.items():
            for with_dist in [True, False]:
                if sample != "main" and not with_dist:
                    continue
                sub = rule(panel[panel["mk"] == mk])
                res, used = model_a(sub, event, with_dist)
                F_all, p_all = wald(res, [{f"DK_k{k}": 1, f"FD_k{k}": -1} for k in [0, 1, 2, 3]])
                F_lead, p_lead = wald(res, [{"DK_km1": 1}, {"FD_km1": 1}])
                base = {"market": mk, "event": event, "sample": sample,
                        "dist_control": with_dist, "N": int(res.nobs),
                        "N_DK": int(used["book_dk"].sum()),
                        "N_FD": int((1 - used["book_dk"]).sum()),
                        "products_x_books": used["entity"].nunique(),
                        "games": used["Game_ID"].nunique(),
                        "F_DK_eq_FD_k0to3": F_all, "p_DK_eq_FD_k0to3": p_all,
                        "F_leads_zero": F_lead, "p_leads_zero": p_lead}
                for b in ["DK", "FD"]:
                    for k in LAGS:
                        name = f"{b}_k{k}".replace("-", "m")
                        results.append({**base, "book": b, "k": k,
                                        "coef_pp": res.params[name], "se_pp": res.bse[name],
                                        "t": res.tvalues[name]})

out = pd.DataFrame(results)
out.to_csv("model_a_results.csv", index=False)

# Print the main specification.
main = out[(out["sample"] == "main") & out["dist_control"]]
for (mk, event), g in main.groupby(["market", "event"], sort=False):
    r = g.iloc[0]
    print(f"\n=== Model A | market: {mk} | event: {event} | N = {r['N']} "
          f"(DK {r['N_DK']}, FD {r['N_FD']}), games = {r['games']}")
    tab = g.pivot(index="k", columns="book", values=["coef_pp", "se_pp"]).round(3)
    print(tab.to_string())
    print(f"DK = FD for k = 0..3: F = {r['F_DK_eq_FD_k0to3']:.2f}, "
          f"p = {r['p_DK_eq_FD_k0to3']:.4f} | leads = 0: F = {r['F_leads_zero']:.2f}, "
          f"p = {r['p_leads_zero']:.4f}")



def within_ols(y, X, entity, clusters):
    """OLS after subtracting entity means from y and X, clustered SEs."""
    X = X.loc[:, X.std() > 0]
    yd = y - y.groupby(entity).transform("mean")
    Xd = X - X.groupby(entity).transform("mean")
    return sm.OLS(yd, Xd).fit(cov_type="cluster", cov_kwds={"groups": clusters})

def block_dummies(df, X):
    """Book x 15-minute block dummies, block 0 as each book's reference."""
    for b, flag in [("DK", df["book_dk"] == 1), ("FD", df["book_dk"] == 0)]:
        for s in range(1, LAST_BLOCK + 1):
            X[f"{b}_block{s}"] = ((df["block"] == s) & flag).astype(float)
    return X


# ---------------------------------------------------------------------------
# 5. Price stickiness: how often the quote changes between snapshots
# ---------------------------------------------------------------------------
# Compared over pairs of consecutive snapshots where the market is open in
# both. A new update time does not always mean a new quote (the book can
# re-confirm a quote without changing it), so changes are measured directly.
st = panel.sort_values(["entity", "n"]).copy()
g = st.groupby("entity")
for c in ["n", "upd", "Point", "BreakEvenOver", "BreakEvenUnder", "Overround"]:
    st["prev_" + c] = g[c].shift()
pairs = st[st["prev_n"] == st["n"] - 1].copy()
pairs["line_changed"] = pairs["Point"] != pairs["prev_Point"]
pairs["odds_changed"] = (((pairs["BreakEvenOver"] - pairs["prev_BreakEvenOver"]).abs() > 1e-9)
                         | ((pairs["BreakEvenUnder"] - pairs["prev_BreakEvenUnder"]).abs() > 1e-9))
pairs["quote_changed"] = pairs["line_changed"] | pairs["odds_changed"]
pairs["margin_changed"] = (pairs["Overround"] - pairs["prev_Overround"]).abs() > 1e-9
pairs["update_time_changed"] = pairs["upd"] != pairs["prev_upd"]
stick = (pairs.groupby(["mk", "Bookmaker"])
         [["quote_changed", "line_changed", "odds_changed", "margin_changed",
           "update_time_changed"]].mean())
stick["pairs"] = pairs.groupby(["mk", "Bookmaker"]).size()
stick.to_csv("stickiness.csv")
print("\n=== Price stickiness: share of consecutive open snapshots with a change")
print(stick.round(3).to_string())


# ---------------------------------------------------------------------------
# 6. Model B: dynamic panel
#    OR(t) = product x book FE + book x time block
#            + rho_b * OR(t-1) + beta0_b * E(t) + beta1_b * E(t-1) + theta * dist
#    estimated book by book inside one regression (every term interacted with
#    each book), which is the same model as writing FanDuel's coefficients plus
#    DraftKings' differences.
# ---------------------------------------------------------------------------
B_SIMS = 20000
rng = np.random.default_rng(2023)

dp = panel.sort_values(["entity", "n"]).copy()
dp["OR"] = dp["Overround"] * 100
g = dp.groupby("entity")
dp["OR_lag"] = g["OR"].shift()
dp["n_lag"] = g["n"].shift()
dp["quote_changed"] = ((dp["Point"] != g["Point"].shift())
                       | ((dp["BreakEvenOver"] - g["BreakEvenOver"].shift()).abs() > 1e-9)
                       | ((dp["BreakEvenUnder"] - g["BreakEvenUnder"].shift()).abs() > 1e-9))
# The lag must be the snapshot immediately before; otherwise the market was
# closed in between and there is no lagged value.
dp = dp[dp["n_lag"] == dp["n"] - 1].copy()

def model_b(df, event):
    df = df[df.groupby("entity")["OR"].transform("size") > 1]
    X = pd.DataFrame(index=df.index)
    for b, flag in [("DK", df["book_dk"] == 1), ("FD", df["book_dk"] == 0)]:
        X[f"{b}_rho"] = df["OR_lag"] * flag
        X[f"{b}_b0"] = df[f"{event}_k0"] * flag
        X[f"{b}_b1"] = df[f"{event}_k1"] * flag
    X = block_dummies(df, X)
    X["dist"] = df["dist"]
    return within_ols(df["OR"], X, df["entity"], df["Game_ID"]), df

def multipliers(rho, b0, b1, H=3):
    m = [b0, b1 + rho * b0]
    for _ in range(2, H + 1):
        m.append(rho * m[-1])
    return m

b_rows = []
for version, rule in [("all", lambda d: d), ("quote_changed", lambda d: d[d["quote_changed"]])]:
    for mk in ["yds", "completions"]:
        for event in EVENTS:
            res, used = model_b(rule(dp[dp["mk"] == mk]), event)
            names = list(res.params.index)
            cov = res.cov_params().values
            draws = rng.multivariate_normal(res.params.values, cov, size=B_SIMS)
            _, p_rho = wald(res, [{"DK_rho": 1, "FD_rho": -1}])
            _, p_ev = wald(res, [{"DK_b0": 1, "FD_b0": -1}, {"DK_b1": 1, "FD_b1": -1}])
            base = {"version": version, "market": mk, "event": event, "N": int(res.nobs),
                    "N_DK": int(used["book_dk"].sum()), "N_FD": int((1 - used["book_dk"]).sum()),
                    "games": used["Game_ID"].nunique(),
                    "p_rho_DK_eq_FD": p_rho, "p_events_DK_eq_FD": p_ev}
            for b in ["DK", "FD"]:
                rho, b0, b1 = (res.params[f"{b}_rho"], res.params[f"{b}_b0"], res.params[f"{b}_b1"])
                i_r, i_0, i_1 = names.index(f"{b}_rho"), names.index(f"{b}_b0"), names.index(f"{b}_b1")
                sim = np.column_stack(multipliers(draws[:, i_r], draws[:, i_0], draws[:, i_1]))
                m = multipliers(rho, b0, b1)
                half_life = np.log(0.5) / np.log(rho) if 0 < rho < 1 else np.nan
                row = {**base, "book": b,
                       "rho": rho, "rho_se": res.bse[f"{b}_rho"],
                       "half_life_snapshots": half_life,
                       "beta0": b0, "beta0_se": res.bse[f"{b}_b0"],
                       "beta1": b1, "beta1_se": res.bse[f"{b}_b1"]}
                for h in range(4):
                    row[f"m{h}"] = m[h]
                    row[f"m{h}_lo"], row[f"m{h}_hi"] = np.percentile(sim[:, h], [2.5, 97.5])
                b_rows.append(row)

b_out = pd.DataFrame(b_rows)
b_out.to_csv("model_b_results.csv", index=False)
print("\n=== Model B (all snapshots): persistence and multipliers, pp")
print(b_out[b_out["version"] == "all"][["market", "event", "book", "N", "rho", "rho_se",
      "half_life_snapshots", "m0", "m1", "m2", "m3", "p_rho_DK_eq_FD", "p_events_DK_eq_FD"]]
      .round(3).to_string(index=False))
print("\n=== Model B (only snapshots where the quote changed): persistence")
print(b_out[b_out["version"] == "quote_changed"][["market", "event", "book", "N", "rho",
      "rho_se", "half_life_snapshots", "p_rho_DK_eq_FD"]].round(3).to_string(index=False))


# ---------------------------------------------------------------------------
# 7. Game state at each snapshot (for Model C)
# ---------------------------------------------------------------------------
# Pregame consensus line: each book's last main line before kickoff, averaged
# over every book that quoted the product.
pre = odds[odds["upd"] <= odds["kickoff"]].copy()
pre["mk"] = pre["Market"].map(MARKETS)
pre = pre[pre["mk"].notna()]
pk = ["Game_ID", "Player", "mk", "Bookmaker"]
pre = pre[pre["upd"] == pre.groupby(pk)["upd"].transform("max")]
pre["dist"] = ((pre["BreakEvenOver"] / (pre["BreakEvenOver"] + pre["BreakEvenUnder"])) - 0.5).abs()
pre = pre.sort_values(pk + ["dist", "Point"], kind="mergesort").drop_duplicates(pk)
pregame_line = pre.groupby(["Game_ID", "Player", "mk"])["Point"].mean().rename("pregame_line")

# The quarterback's team: the team in possession on most of his pass plays.
pp = pbp[(pbp["Play Type"] == "pass") & (pbp["Possession"] != "Unknown")].copy()
pp["qb"] = pp["Description"].str.extract(PASSER)[0].dropna().map(normalise)
qb_team = (pp.dropna(subset=["qb"]).groupby(["Game ID", "qb"])["Possession"]
           .agg(lambda x: x.mode().iloc[0]).rename("team").reset_index()
           .rename(columns={"Game ID": "Game_ID"}))

# Running score after each play. One play carries an impossible score (a
# lead that later shrinks); scores never fall, so each score is capped at the
# lowest score recorded later in the game.
sc = pbp[["Game ID", "wc", "Home Team", "Away Team", "Home Team Points",
          "Away Team Points"]].dropna(subset=["wc"]).rename(columns={"Game ID": "Game_ID"})
for c in ["Home Team Points", "Away Team Points"]:
    sc[c] = sc.groupby("Game_ID")[c].transform(lambda s: s[::-1].cummin()[::-1])
sc = sc.sort_values("wc")
sc["wc"] = sc["wc"].astype("datetime64[ns]")

cells = panel[["Game_ID", "Player", "qb", "mk", "n", "Timestamp"]].drop_duplicates(
    ["Game_ID", "Player", "mk", "n"]).copy()
cells["Timestamp"] = cells["Timestamp"].astype("datetime64[ns]")
cells = cells.merge(qb_team, on=["Game_ID", "qb"], how="left")
cells = pd.merge_asof(cells.sort_values("Timestamp"), sc, left_on="Timestamp", right_on="wc",
                      by="Game_ID", direction="backward")
home = cells["team"] == cells["Home Team"]
away = cells["team"] == cells["Away Team"]
cells["margin"] = np.where(home, cells["Home Team Points"] - cells["Away Team Points"],
                           np.where(away, cells["Away Team Points"] - cells["Home Team Points"],
                                    np.nan))

# Cumulative statistic so far: completions with a time at or before the snapshot.
cs = comp.dropna(subset=["wc"]).sort_values("wc").copy()
cs["wc"] = cs["wc"].astype("datetime64[ns]")
cs["cum_yds"] = cs.groupby(["Game_ID", "qb"])["yards"].cumsum()
cs["cum_cmp"] = cs.groupby(["Game_ID", "qb"]).cumcount() + 1
cells = pd.merge_asof(cells.sort_values("Timestamp"),
                      cs[["Game_ID", "qb", "wc", "cum_yds", "cum_cmp"]].rename(columns={"wc": "wc_c"}),
                      left_on="Timestamp", right_on="wc_c", by=["Game_ID", "qb"],
                      direction="backward")
cells[["cum_yds", "cum_cmp"]] = cells[["cum_yds", "cum_cmp"]].fillna(0)
cells = cells.join(pregame_line, on=["Game_ID", "Player", "mk"])
cells["progress"] = np.where(cells["mk"] == "yds", cells["cum_yds"], cells["cum_cmp"]) / cells["pregame_line"]
print(f"\nGame state: snapshots with a team match {cells['team'].notna().mean():.4f}, "
      f"with a pregame line {cells['pregame_line'].notna().mean():.4f}")


# ---------------------------------------------------------------------------
# 8. Model C: same-moment comparison
#    The product x snapshot fixed effect leaves only the FanDuel minus
#    DraftKings gap at each moment, so the model is estimated on that gap.
#    The gap must also be compared with its own usual level for that bet and
#    that stage of the game: without a product effect and time blocks, events
#    pick up that some quarterbacks have bigger gaps and that the gap grows
#    after the first 15 minutes (the first version of this model made exactly
#    that mistake). So:
#      gap(p,t) = product FE + time block + sum_k delta_k E(t-k) + error
# ---------------------------------------------------------------------------
wide = panel.pivot_table(index=["Game_ID", "Player", "mk", "n"], columns="Bookmaker",
                         values="Overround").dropna()
ev_cols = [c for c in panel.columns if c.startswith("ev_")]
ev_cell = panel.drop_duplicates(["Game_ID", "Player", "mk", "n"]).set_index(
    ["Game_ID", "Player", "mk", "n"])[ev_cols]
gap = wide.join(ev_cell).reset_index()
gap["gap"] = (gap["FanDuel"] - gap["DraftKings"]) * 100
gap = gap.merge(cells[["Game_ID", "Player", "mk", "n", "margin", "progress"]],
                on=["Game_ID", "Player", "mk", "n"], how="left")
gap = gap.merge(grid[["Game_ID", "n", "block"]], on=["Game_ID", "n"])
gap["product"] = gap["Game_ID"] + "|" + gap["Player"] + "|" + gap["mk"]

def time_blocks(df):
    return pd.DataFrame({f"block{s}": (df["block"] == s).astype(float)
                         for s in range(1, LAST_BLOCK + 1)}, index=df.index)

c_rows = []
for mk in ["yds", "completions"]:
    d = gap[gap["mk"] == mk]
    # Average gap (no controls), and the gap by time block, for description.
    r0 = sm.OLS(d["gap"], np.ones(len(d))).fit(cov_type="cluster",
                                                cov_kwds={"groups": d["Game_ID"]})
    c_rows.append({"market": mk, "spec": "mean gap", "term": "const", "coef": r0.params.iloc[0],
                   "se": r0.bse.iloc[0], "N": int(r0.nobs), "games": d["Game_ID"].nunique()})
    for b, v in d.groupby("block")["gap"].mean().items():
        c_rows.append({"market": mk, "spec": "mean gap by block", "term": f"block{b}",
                       "coef": v, "N": int((d["block"] == b).sum())})
    for event in EVENTS:
        X = d[[f"{event}_k{k}".replace("-", "m") for k in LAGS]].astype(float)
        X.columns = [f"k{k}" for k in LAGS]
        X = pd.concat([X, time_blocks(d)], axis=1)
        r = within_ols(d["gap"], X, d["product"], d["Game_ID"])
        _, p = wald(r, [{f"k{k}": 1} for k in [0, 1, 2, 3]])
        _, pl = wald(r, [{"k-1": 1}])
        for k in LAGS:
            c_rows.append({"market": mk, "spec": f"events: {event}", "term": f"k{k}",
                           "coef": r.params[f"k{k}"], "se": r.bse[f"k{k}"], "N": int(r.nobs),
                           "games": d["Game_ID"].nunique(), "p_events_k0to3": p, "p_lead": pl})
    ds = d.dropna(subset=["margin", "progress"])
    X = pd.concat([ds[["margin", "progress"]], time_blocks(ds)], axis=1)
    r = within_ols(ds["gap"], X, ds["product"], ds["Game_ID"])
    for term in ["margin", "progress"]:
        c_rows.append({"market": mk, "spec": "state", "term": term, "coef": r.params[term],
                       "se": r.bse[term], "N": int(r.nobs), "games": ds["Game_ID"].nunique()})
c_out = pd.DataFrame(c_rows)
c_out["t"] = c_out["coef"] / c_out["se"]
c_out.to_csv("model_c_results.csv", index=False)
print("\n=== Model C: FanDuel minus DraftKings overround gap, pp")
print(c_out[c_out["spec"] != "mean gap by block"][["market", "spec", "term", "coef", "se", "t", "N"]]
      .round(3).to_string(index=False))
print("Mean gap by 15-minute block (pp):")
print(c_out[c_out["spec"] == "mean gap by block"].pivot(index="term", columns="market", values="coef")
      .reindex([f"block{b}" for b in range(LAST_BLOCK + 1)]).round(2).T.to_string())

# Check: the gap regression equals the long form with one intercept per bet per
# snapshot (shown here without the product and block terms, which enter both
# forms in the same way).
d = gap[gap["mk"] == "yds"]
long = d.melt(id_vars=["Game_ID", "Player", "n", "ev_c20_k0", "ev_c20_k1"],
              value_vars=["DraftKings", "FanDuel"], var_name="book", value_name="OR")
long["OR"] = long["OR"] * 100
long["fd"] = (long["book"] == "FanDuel").astype(float)
long["cell"] = long["Game_ID"] + long["Player"] + long["n"].astype(str)
Xl = pd.DataFrame({"fd": long["fd"], "fd_k0": long["fd"] * long["ev_c20_k0"],
                   "fd_k1": long["fd"] * long["ev_c20_k1"]})
rf = within_ols(long["OR"], Xl, long["cell"], long["Game_ID"])
rg = sm.OLS(d["gap"], sm.add_constant(d[["ev_c20_k0", "ev_c20_k1"]].astype(float))).fit()
diff = max(abs(rf.params["fd"] - rg.params["const"]),
           abs(rf.params["fd_k0"] - rg.params["ev_c20_k0"]),
           abs(rf.params["fd_k1"] - rg.params["ev_c20_k1"]))
print(f"Check, fixed-effects form vs gap form, largest coefficient difference: {diff:.2e}")


# ---------------------------------------------------------------------------
# 9. Model D: market closures
#    Open(t) = product x book FE + book x time block
#              + sum_k pi_k(DK) E(t-k) x DK + sum_k pi_k(FD) E(t-k) x FD
#    Risk set: every in-play snapshot of the game, for every book x product the
#    book quoted before kickoff. Open = 1 if the book shows the market.
# ---------------------------------------------------------------------------
risk = odds[odds["Bookmaker"].isin(BOOKS) & odds["Market"].isin(MARKETS)
            & (odds["upd"] <= odds["kickoff"])].copy()
risk["mk"] = risk["Market"].map(MARKETS)
risk = risk[["Game_ID", "Player", "qb", "mk", "Bookmaker"]].drop_duplicates()
risk = risk.merge(grid[["Game_ID", "n", "block"]], on="Game_ID")
risk["entity"] = risk["Game_ID"] + "|" + risk["Player"] + "|" + risk["mk"] + "|" + risk["Bookmaker"]
open_set = set(zip(panel["entity"], panel["n"]))
risk["open"] = [int((e, n) in open_set) for e, n in zip(risk["entity"], risk["n"])]
risk = risk.merge(ev_lags, on=["Game_ID", "qb", "n"], how="left")
risk[lag_cols] = risk[lag_cols].fillna(0).astype(int)
risk["book_dk"] = (risk["Bookmaker"] == "DraftKings").astype(int)

# Game state at each snapshot, used as controls in a second version of Model D:
#   own_ball   the quarterback's team had the ball on the last play
#   brk        more than 2 minutes since the last play (a stoppage)
#   plays5     the quarterback's dropbacks in the previous 5 minutes (capped at 5)
# These describe when books keep a quarterback's markets up. They are partly
# changed by the event itself (after a touchdown the other team gets the ball),
# so this version measures closures beyond those state changes.
risk = risk.merge(grid[["Game_ID", "n", "Timestamp"]], on=["Game_ID", "n"])
risk = risk.merge(qb_team, on=["Game_ID", "qb"], how="left")
risk["Timestamp"] = risk["Timestamp"].astype("datetime64[ns]")
last_play = (pbp[["Game ID", "wc", "Possession"]].dropna(subset=["wc"])
             .rename(columns={"Game ID": "Game_ID", "wc": "wc_last"}))
last_play["wc_last"] = last_play["wc_last"].astype("datetime64[ns]")
risk = pd.merge_asof(risk.sort_values("Timestamp"), last_play.sort_values("wc_last"),
                     left_on="Timestamp", right_on="wc_last", by="Game_ID", direction="backward")
risk["own_ball"] = (risk["Possession"] == risk["team"]).astype(int)
risk["brk"] = ((risk["Timestamp"] - risk["wc_last"]).dt.total_seconds() > 120).astype(int)
drop = pbp[pbp["Play Type"] == "pass"].copy()
drop["qb"] = drop["Description"].str.extract(r"([A-Z][\w']*\.[\w'\-]+) (?:pass|steps back|sacked)")[0]
drop = drop.dropna(subset=["qb", "wc"])
drop["qb"] = drop["qb"].map(normalise)
times = {key: np.sort(v["wc"].values.astype("datetime64[ns]"))
         for key, v in drop.rename(columns={"Game ID": "Game_ID"}).groupby(["Game_ID", "qb"])}
five = np.timedelta64(5, "m")
plays5 = []
for gid, qb, t in zip(risk["Game_ID"], risk["qb"], risk["Timestamp"].values):
    a = times.get((gid, qb))
    plays5.append(0 if a is None else
                  int(np.searchsorted(a, t, "right") - np.searchsorted(a, t - five, "right")))
risk["plays5"] = np.minimum(plays5, 5)

# Snapshots where a book shows no market at all, in any market or player.
shown = odds[odds["Bookmaker"].isin(BOOKS)][["Game_ID", "Timestamp", "Bookmaker"]].drop_duplicates()
shown = shown.merge(grid[["Game_ID", "Timestamp", "n"]], on=["Game_ID", "Timestamp"])
shown_set = set(zip(shown["Game_ID"], shown["n"], shown["Bookmaker"]))
risk["book_blank"] = [int((g_, n, b) not in shown_set)
                      for g_, n, b in zip(risk["Game_ID"], risk["n"], risk["Bookmaker"])]
open_in_panel = int(risk["open"].sum())
print(f"\nModel D risk set: {len(risk)} rows, open share by book "
      f"{risk.groupby('Bookmaker')['open'].mean().round(3).to_dict()}, "
      f"book shows nothing: {risk.groupby('Bookmaker')['book_blank'].mean().round(3).to_dict()}")

def model_d(df, event, state=False):
    X = pd.DataFrame(index=df.index)
    for b, flag in [("DK", df["book_dk"] == 1), ("FD", df["book_dk"] == 0)]:
        for k in LAGS:
            X[f"{b}_k{k}".replace("-", "m")] = df[f"{event}_k{k}".replace("-", "m")] * flag
        if state:
            X[f"{b}_own_ball"] = df["own_ball"] * flag
            X[f"{b}_brk"] = df["brk"] * flag
            for j in range(1, 6):
                X[f"{b}_plays{j}"] = ((df["plays5"] == j) & flag).astype(float)
    X = block_dummies(df, X)
    return within_ols(df["open"] * 100, X, df["entity"], df["Game_ID"])

d_rows = []
D_SPECS = [("all", lambda d: d, False),
           ("no_blank", lambda d: d[d["book_blank"] == 0], False),
           ("state_controls", lambda d: d, True)]
for sample, rule, state in D_SPECS:
    for mk in ["yds", "completions"]:
        for event in EVENTS:
            sub = rule(risk[risk["mk"] == mk])
            res = model_d(sub, event, state)
            _, p = wald(res, [{f"DK_k{k}": 1, f"FD_k{k}": -1} for k in [0, 1, 2, 3]])
            _, pl = wald(res, [{"DK_km1": 1}, {"FD_km1": 1}])
            for b in ["DK", "FD"]:
                for k in LAGS:
                    nm = f"{b}_k{k}".replace("-", "m")
                    d_rows.append({"sample": sample, "market": mk, "event": event, "book": b,
                                   "k": k, "coef_pp": res.params[nm], "se_pp": res.bse[nm],
                                   "t": res.tvalues[nm], "N": int(res.nobs),
                                   "open_share": sub["open"].mean(),
                                   "p_DK_eq_FD_k0to3": p, "p_leads_zero": pl})
d_out = pd.DataFrame(d_rows)
# How availability depends on the game state (yards market, state version).
state_res = model_d(risk[risk["mk"] == "yds"], "ev_td", state=True)
d_state = pd.DataFrame({"coef_pp": state_res.params, "se_pp": state_res.bse})
d_state = d_state[d_state.index.str.contains("own_ball|brk|plays")]
d_state.to_csv("model_d_state.csv")
print("\n=== Model D: market availability and game state (yards), pp")
print(d_state.round(2).to_string())
d_out.to_csv("model_d_results.csv", index=False)
for sample in ["all", "state_controls"]:
    print(f"\n=== Model D ({sample}): change in probability the market is open, pp")
    for (mk, event), gg in d_out[d_out["sample"] == sample].groupby(["market", "event"], sort=False):
        r = gg.iloc[0]
        print(f"--- {mk} | {event} | N = {r['N']} | DK = FD (k 0..3): "
              f"p = {r['p_DK_eq_FD_k0to3']:.4f} | leads: p = {r['p_leads_zero']:.4f}")
        print(gg.pivot(index="k", columns="book", values=["coef_pp", "se_pp"]).round(2).to_string())


# ---------------------------------------------------------------------------
# 10. Figures (optional)
# ---------------------------------------------------------------------------
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    LABEL = {"ev_td": "Touchdown pass", "ev_c20": "Completion of 20+ yards",
             "ev_c40": "Completion of 40+ yards"}
    MKT = {"yds": "Passing yards", "completions": "Completions"}
    COL = {"DK": "#185FA5", "FD": "#D85A30"}
    NAME = {"DK": "DraftKings", "FD": "FanDuel"}

    def grid_fig(draw, ylabel, xlabel, fname, xticks, sharey=True):
        fig, axes = plt.subplots(2, 3, figsize=(13, 7), sharex=True, sharey=sharey)
        for i, mk in enumerate(["yds", "completions"]):
            for j, event in enumerate(EVENTS):
                ax = axes[i, j]
                draw(ax, mk, event)
                ax.axhline(0, color="grey", lw=0.8)
                ax.set_xticks(xticks)
                ax.set_title(f"{MKT[mk]}: {LABEL[event]}", fontsize=10)
                if i == 1:
                    ax.set_xlabel(xlabel)
                if j == 0:
                    ax.set_ylabel(ylabel)
        axes[0, 0].legend(fontsize=9)
        fig.tight_layout()
        fig.savefig(fname, dpi=150)
        plt.close(fig)
        print(f"Saved {fname}")

    XLAB = "Snapshots after the event (5 minutes each)"

    # Model A: each book's response path, main specification.
    def draw_a(ax, mk, event):
        g = main[(main["market"] == mk) & (main["event"] == event)]
        for b, shift in [("DK", -0.06), ("FD", 0.06)]:
            s = g[g["book"] == b].sort_values("k")
            ax.errorbar(s["k"] + shift, s["coef_pp"], yerr=1.96 * s["se_pp"], marker="o",
                        capsize=3, color=COL[b], label=NAME[b])
        ax.axvline(-0.5, color="grey", lw=0.8, ls=":")
    grid_fig(draw_a, "Change in overround (pp)", XLAB, "model_a_figure.png", LAGS)

    # Model B: dynamic multipliers with simulated 95 percent intervals.
    def draw_b(ax, mk, event):
        g = b_out[(b_out["version"] == "all") & (b_out["market"] == mk) & (b_out["event"] == event)]
        for b, shift in [("DK", -0.06), ("FD", 0.06)]:
            r = g[g["book"] == b].iloc[0]
            h = np.arange(4)
            m = np.array([r[f"m{i}"] for i in h])
            lo = np.array([r[f"m{i}_lo"] for i in h])
            hi = np.array([r[f"m{i}_hi"] for i in h])
            ax.errorbar(h + shift, m, yerr=[m - lo, hi - m], marker="o", capsize=3,
                        color=COL[b], label=f"{NAME[b]} (rho = {r['rho']:.2f})")
    grid_fig(draw_b, "Change in overround (pp)", XLAB, "model_b_figure.png", [0, 1, 2, 3])

    # Model C: change in the FanDuel minus DraftKings gap after an event.
    def draw_c(ax, mk, event):
        g = c_out[(c_out["market"] == mk) & (c_out["spec"] == f"events: {event}")]
        k = np.array(LAGS)
        coef = np.array([g[g["term"] == f"k{x}"]["coef"].iloc[0] for x in LAGS])
        se = np.array([g[g["term"] == f"k{x}"]["se"].iloc[0] for x in LAGS])
        ax.errorbar(k, coef, yerr=1.96 * se, marker="o", capsize=3, color="#534AB7",
                    label="FanDuel minus DraftKings")
        ax.axvline(-0.5, color="grey", lw=0.8, ls=":")
    grid_fig(draw_c, "Change in gap (pp)", XLAB, "model_c_figure.png", LAGS)

    # Model D: change in the probability the market is open.
    def draw_d(ax, mk, event):
        for sample, ls in [("all", "-"), ("state_controls", "--")]:
            g = d_out[(d_out["sample"] == sample) & (d_out["market"] == mk) & (d_out["event"] == event)]
            for b, shift in [("DK", -0.08), ("FD", 0.08)]:
                s = g[g["book"] == b].sort_values("k")
                lab = NAME[b] + ("" if sample == "all" else ", with state controls")
                ax.errorbar(s["k"] + shift + (0.03 if sample != "all" else 0), s["coef_pp"],
                            yerr=1.96 * s["se_pp"], marker="o" if sample == "all" else "s",
                            ls=ls, capsize=2, color=COL[b], label=lab,
                            alpha=1.0 if sample == "all" else 0.6)
        ax.axvline(-0.5, color="grey", lw=0.8, ls=":")
    grid_fig(draw_d, "Change in probability open (pp)", XLAB, "model_d_figure.png", LAGS)
except ImportError:
    print("\nmatplotlib not installed: figures skipped (pip install matplotlib)")

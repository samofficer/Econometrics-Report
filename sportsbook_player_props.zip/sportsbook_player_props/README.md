# Sportsbook pricing of NFL player props

How five US sportsbooks price NFL quarterback passing props before kickoff, and how
DraftKings and FanDuel price them during games. 2023 season.

## Contents

```
code/
  prop_overround_fe.py     Part 1: pregame panel, Model 1 (fixed effects), calibration,
                           game conditions, Super Bowl comparison
  part2_models.py          Part 2: in-play panel, price stickiness, Models A to D, figures
documents/
  working_paper.pdf/.tex   Working paper draft
  model_specifications.pdf/.tex
                           Full model guide: every variable, every model, data fixes,
                           results and limitations
  literature_review.pdf/.tex
                           First-pass literature review
  model_[a-d]_figure.png   Figures used in both documents (keep them next to the .tex
                           files to compile)
results/
  part1_output.txt         Printed output of prop_overround_fe.py
  part2_output.txt         Printed output of part2_models.py
  model_a_results.csv      Model A: event study coefficients and tests
  model_b_results.csv      Model B: persistence, event coefficients, dynamic multipliers
  model_c_results.csv      Model C: FanDuel minus DraftKings gap
  model_d_results.csv      Model D: market availability after events
  model_d_state.csv        Model D: availability and game state
  stickiness.csv           How often each book changes its quote between snapshots
```

## Running the code

The data files are not included. Put both scripts in the same folder as:

- `PairedOdds_with_Game_ID.xlsx`
- `nfl_playbyplay_full_teams_updated(RAW).csv`

then run, from that folder:

```
pip install -r requirements.txt
python prop_overround_fe.py
python part2_models.py
```

Each script can also take the two file paths as arguments (odds file first). Loading the
Excel file takes about a minute. `part2_models.py` writes `inplay_panel.csv`, the results
files and four figures into the folder it is run from.

Both scripts were run from scratch under Python 3.9 (pandas 2.3) and Python 3.13
(pandas 3.0) with identical results, except that Model B's simulated confidence intervals
differ in the fourth decimal between numpy versions. On Apple Silicon, statsmodels may
print `RuntimeWarning` lines from `matmul` during the F-tests; the results are unaffected.

## Data decisions to know about

These are explained in full in `model_specifications.pdf`, section 2.

- Kickoff is the first play of each game, not the first odds snapshot. Odds collection
  started at 1pm Eastern on busy days and after kickoff in a few games.
- A handful of play times are repaired or filled; 15 odds rows filed under the wrong game
  are dropped; "Zach Wislon" is corrected to Zach Wilson; one impossible score is capped.
- William Hill (US) is dropped as a duplicate of Caesars.
- The main line is the line whose fair over probability is closest to 50 percent.

## Before submitting

- The working paper is a draft. Every number in it comes from the two scripts.
- Check each reference against the original paper before citing. The literature review
  marks entries whose details were not confirmed from a source with a dagger.
- The Model D pre-trend for long completions is unexplained and is reported as a
  limitation.
